package main.najah.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.najah.code.Calculator;

@DisplayName("Calculator Tests")
public class CalculatorTest {
	
    Calculator calc;

	@BeforeEach
	void setUp() throws Exception {
	}

	

}
